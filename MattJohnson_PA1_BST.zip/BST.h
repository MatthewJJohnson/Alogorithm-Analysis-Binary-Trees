/*
 * Binary Search Tree implementation - heavily lifted from https://gist.github.com/mgechev/5911348
 *
 * Simple integer keys and basic operations
 *
 * Aaron Crandall - 2016 - Added / updated:
 *  * Inorder, Preorder, Postorder printouts
 *  * Stubbed in level order printout
 *
 */

#ifndef _BST_H
#define _BST_H

#include <iostream>
#include <queue>
using namespace std;

/*
 *  Node datastructure for single tree node
 */ 
template <class T>
class Node {
public:
	Node(T newData)
	{
		mData = newData;
		mpLeft = nullptr;
		mpRight = nullptr;
	}
	~Node()
	{

	}

	T getData() const 
	{
		return mData;
	}
	Node *& getLeft()
	{
		return mpLeft;
	}

	Node *& getRight()
	{
		return mpRight;
	}

	void setData(const T &newData);
	void setLeft(Node * const newLeft);
	void setRight(Node * const newRight);

private:
	T mData;
	Node *mpLeft;
	Node *mpRight;
};


/*
 * Binary Search Tree (BST) class implementation
 */
template <class T>
class BST {

    private:
    Node<T> *root;

    public:
		BST()
		{
			root = nullptr;
		}

		void add(T val)
		{
			Node<T> *pNode = nullptr;
			pNode = new Node<T>(val);
			addHelper(this->root, pNode);
		}

		void addHelper(Node<T> *& root, Node<T> *pNode)
		{
			if (root == nullptr)//base case
			{
				root = pNode;
			}
			else if (pNode->getData() < root->getData())//direction goes left in the tree
			{
				addHelper(root->getLeft(), pNode);
			}
			else if (pNode->getData() > root->getData())//direction goes right in the tree
			{
				addHelper(root->getRight(), pNode);
			}
			else //newdata == current node's data
			{
				cout << "Tried to insert a Duplicate" << endl;
			}
		}

    void print() 
	{
			this->printPreOrder(); 
    }

	void printPreOrder()
	{
		printPreOrderHelper(this->root);
	}

    void printPreOrderHelper(Node<T> *& root) 
	{
		if (root != nullptr) //first null pointer will be all the way left
		{
			//1. process the node (print stuff)
			cout << root->getData() << endl;
			//2. go left
			printPreOrderHelper(root->getLeft());
			//3. go right
			printPreOrderHelper(root->getRight());
		}
    }

    int nodesCount(Node<T> *& root) 
	{
		int count = 0;
		if (root != nullptr)
		{
			count++; //addnode 
			count = count + nodesCount(root->getLeft()); //recurse
			count = count + nodesCount(root->getRight());//recurse
		}
		return count;
    }

	int height()
	{
		int height = 0;
		height = heightHelper(this->root);
		return (height -1); //returning -1 will cancel the +1 if there is no children (max height)
	}

	int heightHelper(Node<T> *& root)
	{
		if (root == nullptr)
		{
			return 1;
		}
		int leftnode = heightHelper(root->getLeft());//traverse
		int rightnode = heightHelper(root->getRight());//traverse

		if (leftnode > rightnode) //go to the greater node
		{
			return leftnode + 1; //returning +1 in the call stack to add the node to the count
		}
		else
		{
			return rightnode + 1; //returning +1 in the call stack to add the node
		}
	}
};

#endif
